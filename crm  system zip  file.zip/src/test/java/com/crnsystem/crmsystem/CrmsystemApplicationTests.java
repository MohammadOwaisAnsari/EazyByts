package com.crnsystem.crmsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
